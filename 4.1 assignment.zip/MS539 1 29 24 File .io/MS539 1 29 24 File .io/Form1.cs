﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_1_29_24_File.io
{
    public partial class Form1 : Form
    {// local varables go here
        string textFile = "Diary.txt";
        public Form1()
        {
            InitializeComponent();
        }

        // local function here
        static void randy()
        {
            Random random = new Random();
            int num = random.Next(0, 100);
            MessageBox.Show("Your lucky number for the day" + num);
        }
        
       // void display(int num)
        //{ randy(); MessageBox.Show("Your lucky number for the day" + num);}


        private void label1_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = File.AppendText(textFile)) 
                //the nice part is it will append tot the same file
                // if i want new file each time: using(StreamWriter w2 = new StreamWriter(textFile) - always create a new file
            {
                writer.WriteLine(textBox1.Text);
            }
        }
        //the read button is currently hidden
        private void readBTN_Click(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(textFile))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    MessageBox.Show(line);
                }
            }
        }
        //this is to read out the diary entrys
        private void filedialogbtn_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "CHoose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "All file(*.*)|*.*|txt file(*.txt)*.txt";
            openFileDialog1.ShowDialog();

            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filePath = openFileDialog1.FileName;
                WarningException fileStream = openFileDialog1.OpenFile();
                using(StreamReader reader = new StreamReader(textFile))
                {
                    var fileContent = reader.ReadToEnd();
                    textBox1 .Text = fileContent;
                    MessageBox.Show(fileContent);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            randy();
        }
    }
}
