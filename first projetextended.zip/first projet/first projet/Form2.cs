﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace first_projet
{
    public partial class Form2 : Form
    {
        private int timeLeft, num1;
        public Form2()
        {
            InitializeComponent();
        }

        private void BackBTN_Click(object sender, EventArgs e)
        {// this is the back button leading to page 1
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void CheckBTN_Click(object sender, EventArgs e)
        {// this is one wat to check if you have entered a number through a try-catch
            try
            {
                num1 = int.Parse(textBox1.Text);
                MessageBox.Show("Valid entry for Minute Value!");
            }
            catch
            {
                MessageBox.Show("Not valid in using try/catch");
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timerwanted_Tick(object sender, EventArgs e)
        {
            if (this.timeLeft == 0)
            {
                timerwanted.Stop();
                // this is for a message box to alert you the timer is up
                MessageBox.Show("Your time is up!", "Timer");
            }
            else
            {//this is to elp countdown the time
                this.timeLeft--;
                label2.Text = (this.timeLeft / 60).ToString("00");
                label4.Text = (this.timeLeft % 60).ToString("00");
            }
        }

        private void page1ToolStripMenuItem_Click(object sender, EventArgs e)
        {// this is to switch to page 1 from page 2
            Form1 to = new Form1();
            to.Show();
            this.Hide();
        }

        private void TimerBTN_Click(object sender, EventArgs e)
        {
            // this will check if what we entered is a number if it isint the else case is initatedif it is a number it will use the value entered to set the timer.
            if (int.TryParse(textBox1.Text, out int value))
            {
                //Valid integ using parse
           
                // this is the inital clock time for the start of the pomodoro
                this.timeLeft = value * 60;
                // this break down is for the minutes
                label2.Text = (this.timeLeft / 60).ToString("00");
                // this break down is for the seconds
                label4.Text = (this.timeLeft % 60).ToString("00");
                // using the 2nd timer dedicated tot the pomodoro clock
                timerwanted.Start();
            }
            else
            {// if it is not a number: Not valid in using parse
                MessageBox.Show("Please enter a number!");
            }
        }
    }
}
