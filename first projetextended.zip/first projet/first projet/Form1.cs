﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//(name, date, program description)
// Alexis Martinez,1/26/2024, Pormodoro and Tasks holder
//1/21/2024: (2hours) tyring to figure out what I wanted to do exactly
//1/22/2024: (2 hours) trying to figure out how to update the task with the enter key, instead I justed used a button
//1/23/2024: (.5 hours) getting the clock working for the time of the user
//1/24/2024: (2 hours) on the pormodoro timer and different button settings, changing the app desighn
//1/25 2024: (3 hours) trying to clean up code, playing around with asthetics of the app, adding icons and images
namespace first_projet
{
    public partial class Form1 : Form
    {   //this is for the timer 2 countdown variable
        private int timeLeft;
        public Form1()
        {// this initialzes the program and I want to have a welcome message that will keep people productive.
            InitializeComponent();
            MessageBox.Show("Please add your tasks!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {//this timer is for the actuall time of day
            timer1.Start();
        }

       

        private void label1_Click(object sender, EventArgs e)
        {}

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void EnterTask(object sender, EventArgs e)
        {//this is experimental for later if i have a chance
            //this is what happens once you press enter after typing in the
            // Add the text to the CheckedListBox
            //TaskCheckedList.Items.Add(TaskingTextBox.Text);

            // Clear the TextBox
           // TaskingTextBox.Clear();

            
        }

        private void TaskButtonClick(object sender, EventArgs e)
        {// adding a task to the check off list
            // Add the text to the CheckedListBox
            TaskCheckedList.Items.Add(TaskingTextBox.Text);

            // Clear the TextBox
            TaskingTextBox.Clear();
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
          
        }

        private void tick(object sender, EventArgs e)
        {// displays the correct time settings
            Clock.Text = DateTime.Now.ToString("hh:mm:ss");
        }

        private void Clock_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Pomodoroclick(object sender, EventArgs e)
        {// this is the inital clock time for the start of the pomodoro
            this.timeLeft = 25*60;
            // this break down is for the minutes
            lblMinutes.Text = (this.timeLeft/60).ToString("00");
            // this break down is for the seconds
            lblSeconds.Text = (this.timeLeft % 60).ToString("00");
            // using the 2nd timer dedicated tot the pomodoro clock
            timer2.Start();

        }

        private void pomotick(object sender, EventArgs e)
        {
            if (this.timeLeft == 0)
            {
                timer2.Stop();
                // this is for a message box to alert you the timer is up
                MessageBox.Show("Your time is up!", "Timer");
            }
            else
            {//this is to elp countdown the time
                this.timeLeft--;
                lblMinutes.Text = (this.timeLeft / 60).ToString("00");
                lblSeconds.Text = (this.timeLeft % 60).ToString("00");
            }
        }

        private void clickstart(object sender, EventArgs e)
        {
            if (this.timeLeft <= 0)
            {
                timer2.Stop();
            }
            else
            {
                timer2.Start();
            }
        }

        private void ClickStop(object sender, EventArgs e)
        {
            timer2.Stop();
        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void shortbreakclick(object sender, EventArgs e)
        {// this is the shot break set up for only 5 minutes
            this.timeLeft = 5 * 60;
            lblMinutes.Text = (this.timeLeft / 60).ToString("00");
            lblSeconds.Text = (this.timeLeft % 60).ToString("00");
            timer2.Start();
        }

        private void LongBreakClick(object sender, EventArgs e)
        {// this is the long break set up for 15 moinutes
            this.timeLeft = 15 * 60;
            lblMinutes.Text = (this.timeLeft / 60).ToString("00");
            lblSeconds.Text = (this.timeLeft % 60).ToString("00");
            timer2.Start();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void DiffTimerBTN_Click(object sender, EventArgs e)
        { //this is leading to a different timeer page which is to customize timer
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();

        }

        private void TaskingTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void page2ToolStripMenuItem_Click(object sender, EventArgs e)
        {// this is to switch to page 2 fro page1
            Form2 to = new Form2();
            to.Show();
            this.Hide();
        }
    }
}
